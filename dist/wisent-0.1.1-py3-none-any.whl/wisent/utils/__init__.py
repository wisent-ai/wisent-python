"""
Utility functions and classes for the Wisent package.
""" 